export type UserRole = 'admin' | 'client';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  company?: string;
  phone?: string;
  avatar?: string;
  createdAt: string;
}

export interface Project {
  id: string;
  clientId: string;
  clientName: string;
  title: string;
  description: string;
  status: 'proposal' | 'in_progress' | 'review' | 'completed' | 'cancelled';
  startDate: string;
  deadline: string;
  deliveryDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Budget {
  id: string;
  projectId: string;
  clientId: string;
  title: string;
  description: string;
  items: BudgetItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  status: 'draft' | 'sent' | 'approved' | 'rejected' | 'expired';
  validUntil: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  approvedAt?: string;
}

export interface BudgetItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Contract {
  id: string;
  projectId: string;
  budgetId: string;
  clientId: string;
  title: string;
  content: string;
  terms: string[];
  paymentTerms: string;
  totalValue: number;
  status: 'draft' | 'sent' | 'signed' | 'cancelled';
  createdAt: string;
  updatedAt: string;
  signedAt?: string;
  clientSignature?: string;
  adminSignature?: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: string;
}
