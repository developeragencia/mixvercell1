import { useState, useEffect, useCallback } from 'react';
import { Project } from '../types';
import { projectService } from '../services/projectService';
import { useAuth } from './useAuth';

export function useProjects() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadProjects = useCallback(async () => {
    if (!user) {
      setProjects([]);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      
      const data = user.role === 'admin'
        ? await projectService.getAll()
        : await projectService.getByClientId(user.id);
      
      setProjects(data);
    } catch (err) {
      setError('Erro ao carregar projetos');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  const createProject = async (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newProject = await projectService.create(project);
      setProjects(prev => [...prev, newProject]);
      return { success: true, data: newProject };
    } catch (err) {
      return { success: false, error: 'Erro ao criar projeto' };
    }
  };

  const updateProject = async (id: string, data: Partial<Project>) => {
    try {
      const updated = await projectService.update(id, data);
      if (updated) {
        setProjects(prev => prev.map(p => p.id === id ? updated : p));
        return { success: true, data: updated };
      }
      return { success: false, error: 'Projeto não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao atualizar projeto' };
    }
  };

  const deleteProject = async (id: string) => {
    try {
      const success = await projectService.delete(id);
      if (success) {
        setProjects(prev => prev.filter(p => p.id !== id));
        return { success: true };
      }
      return { success: false, error: 'Projeto não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao deletar projeto' };
    }
  };

  return {
    projects,
    isLoading,
    error,
    loadProjects,
    createProject,
    updateProject,
    deleteProject,
  };
}
