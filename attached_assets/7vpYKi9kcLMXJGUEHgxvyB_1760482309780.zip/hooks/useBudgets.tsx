import { useState, useEffect, useCallback } from 'react';
import { Budget } from '../types';
import { budgetService } from '../services/budgetService';
import { useAuth } from './useAuth';

export function useBudgets() {
  const { user } = useAuth();
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadBudgets = useCallback(async () => {
    if (!user) {
      setBudgets([]);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      
      const data = user.role === 'admin'
        ? await budgetService.getAll()
        : await budgetService.getByClientId(user.id);
      
      setBudgets(data);
    } catch (err) {
      setError('Erro ao carregar orçamentos');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadBudgets();
  }, [loadBudgets]);

  const createBudget = async (budget: Omit<Budget, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newBudget = await budgetService.create(budget);
      setBudgets(prev => [...prev, newBudget]);
      return { success: true, data: newBudget };
    } catch (err) {
      return { success: false, error: 'Erro ao criar orçamento' };
    }
  };

  const updateBudget = async (id: string, data: Partial<Budget>) => {
    try {
      const updated = await budgetService.update(id, data);
      if (updated) {
        setBudgets(prev => prev.map(b => b.id === id ? updated : b));
        return { success: true, data: updated };
      }
      return { success: false, error: 'Orçamento não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao atualizar orçamento' };
    }
  };

  const approveBudget = async (id: string) => {
    try {
      const approved = await budgetService.approve(id);
      if (approved) {
        setBudgets(prev => prev.map(b => b.id === id ? approved : b));
        return { success: true, data: approved };
      }
      return { success: false, error: 'Orçamento não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao aprovar orçamento' };
    }
  };

  const rejectBudget = async (id: string) => {
    try {
      const rejected = await budgetService.reject(id);
      if (rejected) {
        setBudgets(prev => prev.map(b => b.id === id ? rejected : b));
        return { success: true, data: rejected };
      }
      return { success: false, error: 'Orçamento não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao rejeitar orçamento' };
    }
  };

  const deleteBudget = async (id: string) => {
    try {
      const success = await budgetService.delete(id);
      if (success) {
        setBudgets(prev => prev.filter(b => b.id !== id));
        return { success: true };
      }
      return { success: false, error: 'Orçamento não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao deletar orçamento' };
    }
  };

  return {
    budgets,
    isLoading,
    error,
    loadBudgets,
    createBudget,
    updateBudget,
    approveBudget,
    rejectBudget,
    deleteBudget,
  };
}
