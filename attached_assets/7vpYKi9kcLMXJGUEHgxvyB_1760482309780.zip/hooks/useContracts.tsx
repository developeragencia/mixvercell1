import { useState, useEffect, useCallback } from 'react';
import { Contract } from '../types';
import { contractService } from '../services/contractService';
import { useAuth } from './useAuth';

export function useContracts() {
  const { user } = useAuth();
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadContracts = useCallback(async () => {
    if (!user) {
      setContracts([]);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      
      const data = user.role === 'admin'
        ? await contractService.getAll()
        : await contractService.getByClientId(user.id);
      
      setContracts(data);
    } catch (err) {
      setError('Erro ao carregar contratos');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadContracts();
  }, [loadContracts]);

  const createContract = async (contract: Omit<Contract, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const newContract = await contractService.create(contract);
      setContracts(prev => [...prev, newContract]);
      return { success: true, data: newContract };
    } catch (err) {
      return { success: false, error: 'Erro ao criar contrato' };
    }
  };

  const updateContract = async (id: string, data: Partial<Contract>) => {
    try {
      const updated = await contractService.update(id, data);
      if (updated) {
        setContracts(prev => prev.map(c => c.id === id ? updated : c));
        return { success: true, data: updated };
      }
      return { success: false, error: 'Contrato não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao atualizar contrato' };
    }
  };

  const signContract = async (id: string, signature: string) => {
    if (!user) return { success: false, error: 'Usuário não autenticado' };
    
    try {
      const signed = await contractService.sign(id, signature, user.role === 'client');
      if (signed) {
        setContracts(prev => prev.map(c => c.id === id ? signed : c));
        return { success: true, data: signed };
      }
      return { success: false, error: 'Contrato não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao assinar contrato' };
    }
  };

  const deleteContract = async (id: string) => {
    try {
      const success = await contractService.delete(id);
      if (success) {
        setContracts(prev => prev.filter(c => c.id !== id));
        return { success: true };
      }
      return { success: false, error: 'Contrato não encontrado' };
    } catch (err) {
      return { success: false, error: 'Erro ao deletar contrato' };
    }
  };

  return {
    contracts,
    isLoading,
    error,
    loadContracts,
    createContract,
    updateContract,
    signContract,
    deleteContract,
  };
}
