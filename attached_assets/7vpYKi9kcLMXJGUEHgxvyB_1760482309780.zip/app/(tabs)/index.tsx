import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { useAuth } from '../../hooks/useAuth';
import { useProjects } from '../../hooks/useProjects';
import { useBudgets } from '../../hooks/useBudgets';
import { useContracts } from '../../hooks/useContracts';
import { theme } from '../../constants/theme';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { projects } = useProjects();
  const { budgets } = useBudgets();
  const { contracts } = useContracts();

  const isAdmin = user?.role === 'admin';

  const stats = {
    totalProjects: projects.length,
    activeProjects: projects.filter(p => p.status === 'in_progress').length,
    completedProjects: projects.filter(p => p.status === 'completed').length,
    
    pendingBudgets: budgets.filter(b => b.status === 'sent').length,
    approvedBudgets: budgets.filter(b => b.status === 'approved').length,
    totalRevenue: budgets
      .filter(b => b.status === 'approved')
      .reduce((sum, b) => sum + b.total, 0),
    
    pendingContracts: contracts.filter(c => c.status === 'sent').length,
    signedContracts: contracts.filter(c => c.status === 'signed').length,
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const StatCard = ({ 
    icon, 
    title, 
    value, 
    color, 
    subtitle 
  }: { 
    icon: keyof typeof MaterialIcons.glyphMap; 
    title: string; 
    value: string | number; 
    color: string;
    subtitle?: string;
  }) => (
    <View style={[styles.statCard, { borderLeftColor: color, borderLeftWidth: 4 }]}>
      <View style={styles.statIconContainer}>
        <MaterialIcons name={icon} size={28} color={color} />
      </View>
      <View style={styles.statContent}>
        <Text style={styles.statTitle}>{title}</Text>
        <Text style={styles.statValue}>{value}</Text>
        {subtitle && <Text style={styles.statSubtitle}>{subtitle}</Text>}
      </View>
    </View>
  );

  return (
    <ScrollView style={[styles.container, { paddingTop: insets.top }]} contentContainerStyle={styles.content}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Olá, {user?.name?.split(' ')[0]}! 👋</Text>
          <Text style={styles.subtitle}>
            {isAdmin ? 'Painel Administrativo' : 'Área do Cliente'}
          </Text>
        </View>
        <TouchableOpacity style={styles.notificationButton}>
          <MaterialIcons name="notifications" size={24} color={theme.colors.text} />
          <View style={styles.notificationBadge}>
            <Text style={styles.notificationBadgeText}>3</Text>
          </View>
        </TouchableOpacity>
      </View>

      {/* Projetos */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Projetos</Text>
        <View style={styles.statsRow}>
          <StatCard
            icon="work"
            title="Total"
            value={stats.totalProjects}
            color={theme.colors.primary}
          />
          <StatCard
            icon="trending-up"
            title="Em Andamento"
            value={stats.activeProjects}
            color={theme.colors.info}
          />
          <StatCard
            icon="check-circle"
            title="Concluídos"
            value={stats.completedProjects}
            color={theme.colors.success}
          />
        </View>
      </View>

      {/* Orçamentos */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Orçamentos</Text>
        <View style={styles.statsRow}>
          <StatCard
            icon="schedule"
            title="Pendentes"
            value={stats.pendingBudgets}
            color={theme.colors.warning}
          />
          <StatCard
            icon="thumb-up"
            title="Aprovados"
            value={stats.approvedBudgets}
            color={theme.colors.success}
          />
          {isAdmin && (
            <StatCard
              icon="payments"
              title="Receita Total"
              value={formatCurrency(stats.totalRevenue)}
              color={theme.colors.secondary}
            />
          )}
        </View>
      </View>

      {/* Contratos */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Contratos</Text>
        <View style={styles.statsRow}>
          <StatCard
            icon="pending-actions"
            title="Aguardando"
            value={stats.pendingContracts}
            color={theme.colors.accent}
          />
          <StatCard
            icon="done-all"
            title="Assinados"
            value={stats.signedContracts}
            color={theme.colors.success}
          />
        </View>
      </View>

      {/* Ações Rápidas */}
      {isAdmin && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Ações Rápidas</Text>
          <View style={styles.quickActions}>
            <TouchableOpacity style={styles.quickActionButton}>
              <MaterialIcons name="add" size={24} color={theme.colors.primary} />
              <Text style={styles.quickActionText}>Novo Projeto</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickActionButton}>
              <MaterialIcons name="receipt-long" size={24} color={theme.colors.secondary} />
              <Text style={styles.quickActionText}>Criar Orçamento</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickActionButton}>
              <MaterialIcons name="description" size={24} color={theme.colors.accent} />
              <Text style={styles.quickActionText}>Gerar Contrato</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Resumo da Semana */}
      <View style={styles.weeklyCard}>
        <View style={styles.weeklyHeader}>
          <MaterialIcons name="calendar-today" size={20} color={theme.colors.primary} />
          <Text style={styles.weeklyTitle}>Resumo da Semana</Text>
        </View>
        <View style={styles.weeklyContent}>
          <View style={styles.weeklyItem}>
            <View style={[styles.weeklyDot, { backgroundColor: theme.colors.primary }]} />
            <Text style={styles.weeklyText}>2 novos projetos iniciados</Text>
          </View>
          <View style={styles.weeklyItem}>
            <View style={[styles.weeklyDot, { backgroundColor: theme.colors.success }]} />
            <Text style={styles.weeklyText}>3 orçamentos aprovados</Text>
          </View>
          <View style={styles.weeklyItem}>
            <View style={[styles.weeklyDot, { backgroundColor: theme.colors.info }]} />
            <Text style={styles.weeklyText}>1 contrato assinado</Text>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  content: {
    padding: theme.spacing.md,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },
  greeting: {
    fontSize: theme.fontSize.xxl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    fontSize: theme.fontSize.md,
    color: theme.colors.textSecondary,
  },
  notificationButton: {
    position: 'relative',
    padding: theme.spacing.sm,
  },
  notificationBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    backgroundColor: theme.colors.error,
    borderRadius: theme.borderRadius.full,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notificationBadgeText: {
    fontSize: 10,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.surface,
  },
  section: {
    marginBottom: theme.spacing.xl,
  },
  sectionTitle: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  statsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -theme.spacing.xs,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    margin: theme.spacing.xs,
    flexDirection: 'row',
    alignItems: 'center',
    ...theme.shadows.sm,
  },
  statIconContainer: {
    marginRight: theme.spacing.md,
  },
  statContent: {
    flex: 1,
  },
  statTitle: {
    fontSize: theme.fontSize.xs,
    color: theme.colors.textSecondary,
    marginBottom: 4,
  },
  statValue: {
    fontSize: theme.fontSize.xl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
  },
  statSubtitle: {
    fontSize: theme.fontSize.xs,
    color: theme.colors.textLight,
    marginTop: 2,
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -theme.spacing.xs,
  },
  quickActionButton: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    margin: theme.spacing.xs,
    alignItems: 'center',
    ...theme.shadows.sm,
  },
  quickActionText: {
    fontSize: theme.fontSize.sm,
    fontWeight: theme.fontWeight.medium,
    color: theme.colors.text,
    marginTop: theme.spacing.sm,
    textAlign: 'center',
  },
  weeklyCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    ...theme.shadows.sm,
  },
  weeklyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
    gap: theme.spacing.sm,
  },
  weeklyTitle: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.text,
  },
  weeklyContent: {
    gap: theme.spacing.sm,
  },
  weeklyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.sm,
  },
  weeklyDot: {
    width: 8,
    height: 8,
    borderRadius: theme.borderRadius.full,
  },
  weeklyText: {
    fontSize: theme.fontSize.md,
    color: theme.colors.textSecondary,
  },
});
