import React from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import { useBudgets } from '../../hooks/useBudgets';
import BudgetCard from '../../components/BudgetCard';
import EmptyState from '../../components/EmptyState';
import { theme } from '../../constants/theme';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function BudgetsScreen() {
  const insets = useSafeAreaInsets();
  const { budgets, isLoading } = useBudgets();

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Orçamentos</Text>
        <Text style={styles.subtitle}>{budgets.length} {budgets.length === 1 ? 'orçamento' : 'orçamentos'}</Text>
      </View>

      {budgets.length === 0 ? (
        <EmptyState
          icon="receipt-long"
          title="Nenhum orçamento"
          message="Você ainda não tem orçamentos cadastrados. Seus orçamentos aparecerão aqui."
        />
      ) : (
        <FlatList
          data={budgets}
          keyExtractor={item => item.id}
          renderItem={({ item }) => <BudgetCard budget={item} />}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  title: {
    fontSize: theme.fontSize.xxl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    fontSize: theme.fontSize.md,
    color: theme.colors.textSecondary,
  },
  list: {
    padding: theme.spacing.md,
  },
});
