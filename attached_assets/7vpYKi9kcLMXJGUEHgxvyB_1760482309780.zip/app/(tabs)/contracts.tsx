import React from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import { useContracts } from '../../hooks/useContracts';
import ContractCard from '../../components/ContractCard';
import EmptyState from '../../components/EmptyState';
import { theme } from '../../constants/theme';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function ContractsScreen() {
  const insets = useSafeAreaInsets();
  const { contracts, isLoading } = useContracts();

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Contratos</Text>
        <Text style={styles.subtitle}>{contracts.length} {contracts.length === 1 ? 'contrato' : 'contratos'}</Text>
      </View>

      {contracts.length === 0 ? (
        <EmptyState
          icon="description"
          title="Nenhum contrato"
          message="Você ainda não tem contratos cadastrados. Seus contratos aparecerão aqui."
        />
      ) : (
        <FlatList
          data={contracts}
          keyExtractor={item => item.id}
          renderItem={({ item }) => <ContractCard contract={item} />}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    padding: theme.spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  title: {
    fontSize: theme.fontSize.xxl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  subtitle: {
    fontSize: theme.fontSize.md,
    color: theme.colors.textSecondary,
  },
  list: {
    padding: theme.spacing.md,
  },
});
