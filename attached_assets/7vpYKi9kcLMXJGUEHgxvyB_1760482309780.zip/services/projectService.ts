import { Project } from '../types';
import { storageService } from './storageService';

export const projectService = {
  async getAll(): Promise<Project[]> {
    const projects = await storageService.get<Project[]>(storageService.keys.PROJECTS);
    return projects || [];
  },

  async getById(id: string): Promise<Project | null> {
    const projects = await this.getAll();
    return projects.find(p => p.id === id) || null;
  },

  async getByClientId(clientId: string): Promise<Project[]> {
    const projects = await this.getAll();
    return projects.filter(p => p.clientId === clientId);
  },

  async create(project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>): Promise<Project> {
    const projects = await this.getAll();
    const newProject: Project = {
      ...project,
      id: `proj_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    projects.push(newProject);
    await storageService.save(storageService.keys.PROJECTS, projects);
    return newProject;
  },

  async update(id: string, data: Partial<Project>): Promise<Project | null> {
    const projects = await this.getAll();
    const index = projects.findIndex(p => p.id === id);
    if (index === -1) return null;
    
    projects[index] = {
      ...projects[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    await storageService.save(storageService.keys.PROJECTS, projects);
    return projects[index];
  },

  async delete(id: string): Promise<boolean> {
    const projects = await this.getAll();
    const filtered = projects.filter(p => p.id !== id);
    if (filtered.length === projects.length) return false;
    await storageService.save(storageService.keys.PROJECTS, filtered);
    return true;
  },
};
