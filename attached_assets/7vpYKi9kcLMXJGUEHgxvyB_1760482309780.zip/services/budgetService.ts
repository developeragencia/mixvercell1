import { Budget, BudgetItem } from '../types';
import { storageService } from './storageService';

export const budgetService = {
  async getAll(): Promise<Budget[]> {
    const budgets = await storageService.get<Budget[]>(storageService.keys.BUDGETS);
    return budgets || [];
  },

  async getById(id: string): Promise<Budget | null> {
    const budgets = await this.getAll();
    return budgets.find(b => b.id === id) || null;
  },

  async getByClientId(clientId: string): Promise<Budget[]> {
    const budgets = await this.getAll();
    return budgets.filter(b => b.clientId === clientId);
  },

  async getByProjectId(projectId: string): Promise<Budget[]> {
    const budgets = await this.getAll();
    return budgets.filter(b => b.projectId === projectId);
  },

  calculateTotal(items: BudgetItem[], discount: number = 0, tax: number = 0): {
    subtotal: number;
    total: number;
  } {
    const subtotal = items.reduce((sum, item) => sum + item.total, 0);
    const discountAmount = (subtotal * discount) / 100;
    const taxAmount = ((subtotal - discountAmount) * tax) / 100;
    const total = subtotal - discountAmount + taxAmount;
    return { subtotal, total };
  },

  async create(budget: Omit<Budget, 'id' | 'createdAt' | 'updatedAt'>): Promise<Budget> {
    const budgets = await this.getAll();
    const newBudget: Budget = {
      ...budget,
      id: `budget_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    budgets.push(newBudget);
    await storageService.save(storageService.keys.BUDGETS, budgets);
    return newBudget;
  },

  async update(id: string, data: Partial<Budget>): Promise<Budget | null> {
    const budgets = await this.getAll();
    const index = budgets.findIndex(b => b.id === id);
    if (index === -1) return null;
    
    budgets[index] = {
      ...budgets[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    await storageService.save(storageService.keys.BUDGETS, budgets);
    return budgets[index];
  },

  async approve(id: string): Promise<Budget | null> {
    return this.update(id, {
      status: 'approved',
      approvedAt: new Date().toISOString(),
    });
  },

  async reject(id: string): Promise<Budget | null> {
    return this.update(id, { status: 'rejected' });
  },

  async delete(id: string): Promise<boolean> {
    const budgets = await this.getAll();
    const filtered = budgets.filter(b => b.id !== id);
    if (filtered.length === budgets.length) return false;
    await storageService.save(storageService.keys.BUDGETS, filtered);
    return true;
  },
};
