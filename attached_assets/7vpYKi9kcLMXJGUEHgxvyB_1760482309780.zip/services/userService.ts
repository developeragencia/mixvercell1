import { User } from '../types';
import { storageService } from './storageService';

export const userService = {
  async getAll(): Promise<User[]> {
    const users = await storageService.get<User[]>(storageService.keys.USERS);
    return users || [];
  },

  async getById(id: string): Promise<User | null> {
    const users = await this.getAll();
    return users.find(u => u.id === id) || null;
  },

  async getByEmail(email: string): Promise<User | null> {
    const users = await this.getAll();
    return users.find(u => u.email === email) || null;
  },

  async getClients(): Promise<User[]> {
    const users = await this.getAll();
    return users.filter(u => u.role === 'client');
  },

  async create(user: Omit<User, 'id' | 'createdAt'>): Promise<User> {
    const users = await this.getAll();
    const newUser: User = {
      ...user,
      id: `user_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    await storageService.save(storageService.keys.USERS, users);
    return newUser;
  },

  async update(id: string, data: Partial<User>): Promise<User | null> {
    const users = await this.getAll();
    const index = users.findIndex(u => u.id === id);
    if (index === -1) return null;
    
    users[index] = { ...users[index], ...data };
    await storageService.save(storageService.keys.USERS, users);
    return users[index];
  },

  async delete(id: string): Promise<boolean> {
    const users = await this.getAll();
    const filtered = users.filter(u => u.id !== id);
    if (filtered.length === users.length) return false;
    await storageService.save(storageService.keys.USERS, filtered);
    return true;
  },

  async initializeMockData(): Promise<void> {
    const users = await this.getAll();
    if (users.length > 0) return;

    const mockUsers: User[] = [
      {
        id: 'admin_1',
        name: 'Admin DevFlow',
        email: 'admin@devflow.com',
        role: 'admin',
        company: 'DevFlow Studio',
        phone: '+55 11 98765-4321',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'client_1',
        name: 'João Silva',
        email: 'joao@empresa.com',
        role: 'client',
        company: 'Empresa XYZ Ltda',
        phone: '+55 11 91234-5678',
        createdAt: new Date().toISOString(),
      },
      {
        id: 'client_2',
        name: 'Maria Santos',
        email: 'maria@startup.com',
        role: 'client',
        company: 'Startup Inovadora',
        phone: '+55 11 92345-6789',
        createdAt: new Date().toISOString(),
      },
    ];

    await storageService.save(storageService.keys.USERS, mockUsers);
  },
};
