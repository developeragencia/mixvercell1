import { Contract } from '../types';
import { storageService } from './storageService';

export const contractService = {
  async getAll(): Promise<Contract[]> {
    const contracts = await storageService.get<Contract[]>(storageService.keys.CONTRACTS);
    return contracts || [];
  },

  async getById(id: string): Promise<Contract | null> {
    const contracts = await this.getAll();
    return contracts.find(c => c.id === id) || null;
  },

  async getByClientId(clientId: string): Promise<Contract[]> {
    const contracts = await this.getAll();
    return contracts.filter(c => c.clientId === clientId);
  },

  async getByProjectId(projectId: string): Promise<Contract[]> {
    const contracts = await this.getAll();
    return contracts.filter(c => c.projectId === projectId);
  },

  async create(contract: Omit<Contract, 'id' | 'createdAt' | 'updatedAt'>): Promise<Contract> {
    const contracts = await this.getAll();
    const newContract: Contract = {
      ...contract,
      id: `contract_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    contracts.push(newContract);
    await storageService.save(storageService.keys.CONTRACTS, contracts);
    return newContract;
  },

  async update(id: string, data: Partial<Contract>): Promise<Contract | null> {
    const contracts = await this.getAll();
    const index = contracts.findIndex(c => c.id === id);
    if (index === -1) return null;
    
    contracts[index] = {
      ...contracts[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    await storageService.save(storageService.keys.CONTRACTS, contracts);
    return contracts[index];
  },

  async sign(id: string, signature: string, isClient: boolean): Promise<Contract | null> {
    const contract = await this.getById(id);
    if (!contract) return null;

    const updateData: Partial<Contract> = isClient
      ? { clientSignature: signature }
      : { adminSignature: signature };

    const updated = await this.update(id, updateData);
    if (!updated) return null;

    // Se ambas as assinaturas estiverem presentes, marcar como assinado
    if (updated.clientSignature && updated.adminSignature) {
      return this.update(id, {
        status: 'signed',
        signedAt: new Date().toISOString(),
      });
    }

    return updated;
  },

  async delete(id: string): Promise<boolean> {
    const contracts = await this.getAll();
    const filtered = contracts.filter(c => c.id !== id);
    if (filtered.length === contracts.length) return false;
    await storageService.save(storageService.keys.CONTRACTS, filtered);
    return true;
  },
};
