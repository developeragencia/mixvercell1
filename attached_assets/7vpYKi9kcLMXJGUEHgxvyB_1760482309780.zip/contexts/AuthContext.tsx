import React, { createContext, ReactNode, useState, useEffect } from 'react';
import { User } from '../types';
import { storageService } from '../services/storageService';
import { userService } from '../services/userService';

export interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateUser: (data: Partial<User>) => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      await userService.initializeMockData();
      const savedUser = await storageService.get<User>(storageService.keys.USER);
      setUser(savedUser);
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const foundUser = await userService.getByEmail(email);
      
      if (!foundUser) {
        return { success: false, error: 'Usuário não encontrado' };
      }

      // Mock password validation (in production, use proper authentication)
      if (password.length < 3) {
        return { success: false, error: 'Senha inválida' };
      }

      await storageService.save(storageService.keys.USER, foundUser);
      setUser(foundUser);
      return { success: true };
    } catch (error) {
      return { success: false, error: 'Erro ao fazer login' };
    }
  };

  const logout = async () => {
    try {
      await storageService.remove(storageService.keys.USER);
      setUser(null);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const updateUser = async (data: Partial<User>) => {
    if (!user) return;
    
    try {
      const updated = await userService.update(user.id, data);
      if (updated) {
        await storageService.save(storageService.keys.USER, updated);
        setUser(updated);
      }
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}
