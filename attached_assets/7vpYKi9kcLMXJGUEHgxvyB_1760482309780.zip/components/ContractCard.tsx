import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Contract } from '../types';
import { theme } from '../constants/theme';
import StatusBadge from './StatusBadge';

interface ContractCardProps {
  contract: Contract;
  onPress?: () => void;
}

export default function ContractCard({ contract, onPress }: ContractCardProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const getSignatureStatus = () => {
    if (contract.status === 'signed') return 'Assinado por ambas as partes';
    if (contract.clientSignature && !contract.adminSignature) return 'Aguardando assinatura do desenvolvedor';
    if (contract.adminSignature && !contract.clientSignature) return 'Aguardando assinatura do cliente';
    return 'Aguardando assinaturas';
  };

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <Text style={styles.title}>{contract.title}</Text>
        <StatusBadge status={contract.status} />
      </View>
      
      <View style={styles.valueRow}>
        <MaterialIcons name="attach-money" size={20} color={theme.colors.primary} />
        <Text style={styles.value}>{formatCurrency(contract.totalValue)}</Text>
      </View>
      
      <View style={styles.divider} />
      
      <View style={styles.infoRow}>
        <MaterialIcons name="calendar-today" size={16} color={theme.colors.textSecondary} />
        <Text style={styles.infoText}>Criado em {formatDate(contract.createdAt)}</Text>
      </View>
      
      {contract.signedAt && (
        <View style={styles.infoRow}>
          <MaterialIcons name="check-circle" size={16} color={theme.colors.success} />
          <Text style={styles.infoText}>Assinado em {formatDate(contract.signedAt)}</Text>
        </View>
      )}
      
      <View style={styles.signatureStatus}>
        <MaterialIcons 
          name={contract.status === 'signed' ? 'done-all' : 'pending-actions'} 
          size={16} 
          color={contract.status === 'signed' ? theme.colors.success : theme.colors.warning}
        />
        <Text style={styles.signatureText}>{getSignatureStatus()}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    ...theme.shadows.sm,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: theme.spacing.md,
  },
  title: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.text,
    flex: 1,
    marginRight: theme.spacing.sm,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  value: {
    fontSize: theme.fontSize.xl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
    marginLeft: theme.spacing.xs,
  },
  divider: {
    height: 1,
    backgroundColor: theme.colors.border,
    marginVertical: theme.spacing.sm,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: theme.spacing.xs,
  },
  infoText: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
  },
  signatureStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: theme.spacing.sm,
    padding: theme.spacing.sm,
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.sm,
  },
  signatureText: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.text,
    flex: 1,
  },
});
