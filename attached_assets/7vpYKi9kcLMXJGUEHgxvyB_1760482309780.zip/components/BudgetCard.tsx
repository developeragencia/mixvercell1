import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Budget } from '../types';
import { theme } from '../constants/theme';
import StatusBadge from './StatusBadge';

interface BudgetCardProps {
  budget: Budget;
  onPress?: () => void;
}

export default function BudgetCard({ budget, onPress }: BudgetCardProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <Text style={styles.title}>{budget.title}</Text>
        <StatusBadge status={budget.status} />
      </View>
      
      <Text style={styles.description} numberOfLines={2}>
        {budget.description}
      </Text>
      
      <View style={styles.divider} />
      
      <View style={styles.itemsInfo}>
        <MaterialIcons name="format-list-bulleted" size={16} color={theme.colors.textSecondary} />
        <Text style={styles.itemsText}>{budget.items.length} itens</Text>
      </View>
      
      <View style={styles.footer}>
        <View>
          <Text style={styles.totalLabel}>Valor Total</Text>
          <Text style={styles.totalValue}>{formatCurrency(budget.total)}</Text>
        </View>
        
        <View style={styles.validUntil}>
          <MaterialIcons name="schedule" size={14} color={theme.colors.textSecondary} />
          <Text style={styles.validText}>Válido até {formatDate(budget.validUntil)}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    ...theme.shadows.sm,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: theme.spacing.sm,
  },
  title: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.text,
    flex: 1,
    marginRight: theme.spacing.sm,
  },
  description: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.sm,
    lineHeight: 20,
  },
  divider: {
    height: 1,
    backgroundColor: theme.colors.border,
    marginVertical: theme.spacing.sm,
  },
  itemsInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: theme.spacing.md,
  },
  itemsText: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  totalLabel: {
    fontSize: theme.fontSize.xs,
    color: theme.colors.textSecondary,
    marginBottom: 2,
  },
  totalValue: {
    fontSize: theme.fontSize.xl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
  },
  validUntil: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  validText: {
    fontSize: theme.fontSize.xs,
    color: theme.colors.textSecondary,
  },
});
