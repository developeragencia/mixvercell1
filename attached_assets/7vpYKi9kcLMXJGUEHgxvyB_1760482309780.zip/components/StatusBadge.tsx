import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { theme } from '../constants/theme';

interface StatusBadgeProps {
  status: string;
  label?: string;
}

const statusConfig: Record<string, { color: string; label: string }> = {
  proposal: { color: theme.colors.status.proposal, label: 'Proposta' },
  in_progress: { color: theme.colors.status.inProgress, label: 'Em Andamento' },
  review: { color: theme.colors.status.review, label: 'Em Revisão' },
  completed: { color: theme.colors.status.completed, label: 'Concluído' },
  cancelled: { color: theme.colors.status.cancelled, label: 'Cancelado' },
  
  draft: { color: theme.colors.status.draft, label: 'Rascunho' },
  sent: { color: theme.colors.status.sent, label: 'Enviado' },
  approved: { color: theme.colors.status.approved, label: 'Aprovado' },
  rejected: { color: theme.colors.status.rejected, label: 'Rejeitado' },
  signed: { color: theme.colors.status.signed, label: 'Assinado' },
  expired: { color: theme.colors.status.expired, label: 'Expirado' },
};

export default function StatusBadge({ status, label }: StatusBadgeProps) {
  const config = statusConfig[status] || { color: theme.colors.textSecondary, label: status };
  const displayLabel = label || config.label;

  return (
    <View style={[styles.badge, { backgroundColor: config.color }]}>
      <Text style={styles.text}>{displayLabel}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: theme.borderRadius.sm,
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: theme.fontSize.xs,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.surface,
  },
});
