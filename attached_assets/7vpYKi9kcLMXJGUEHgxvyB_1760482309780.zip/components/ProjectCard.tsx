import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Project } from '../types';
import { theme } from '../constants/theme';
import { commonStyles } from '../constants/styles';
import StatusBadge from './StatusBadge';

interface ProjectCardProps {
  project: Project;
  onPress?: () => void;
}

export default function ProjectCard({ project, onPress }: ProjectCardProps) {
  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  const getDaysRemaining = () => {
    const deadline = new Date(project.deadline);
    const today = new Date();
    const diff = Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  const daysRemaining = getDaysRemaining();
  const isOverdue = daysRemaining < 0;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={commonStyles.rowBetween}>
        <Text style={styles.title}>{project.title}</Text>
        <StatusBadge status={project.status} />
      </View>
      
      <Text style={styles.client}>
        <MaterialIcons name="person" size={16} color={theme.colors.textSecondary} />
        {' '}{project.clientName}
      </Text>
      
      <Text style={styles.description} numberOfLines={2}>
        {project.description}
      </Text>
      
      <View style={styles.footer}>
        <View style={styles.dateInfo}>
          <MaterialIcons name="calendar-today" size={14} color={theme.colors.textSecondary} />
          <Text style={styles.dateText}>Prazo: {formatDate(project.deadline)}</Text>
        </View>
        
        {project.status !== 'completed' && project.status !== 'cancelled' && (
          <View style={[styles.daysRemaining, isOverdue && styles.overdue]}>
            <Text style={[styles.daysText, isOverdue && styles.overdueText]}>
              {isOverdue ? `${Math.abs(daysRemaining)}d atrasado` : `${daysRemaining}d restantes`}
            </Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    ...theme.shadows.sm,
  },
  title: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
    flex: 1,
    marginRight: theme.spacing.sm,
  },
  client: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.sm,
  },
  description: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.md,
    lineHeight: 20,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dateInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  dateText: {
    fontSize: theme.fontSize.xs,
    color: theme.colors.textSecondary,
  },
  daysRemaining: {
    backgroundColor: theme.colors.info + '20',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: theme.borderRadius.sm,
  },
  daysText: {
    fontSize: theme.fontSize.xs,
    fontWeight: theme.fontWeight.medium,
    color: theme.colors.info,
  },
  overdue: {
    backgroundColor: theme.colors.error + '20',
  },
  overdueText: {
    color: theme.colors.error,
  },
});
